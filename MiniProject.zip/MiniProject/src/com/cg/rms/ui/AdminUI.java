package com.cg.rms.ui;

public interface AdminUI {
	


}
