package com.cg.rms.exception;
public class RecruitmentException extends Exception{
	
	public RecruitmentException() {
		
	}
	
	
	public RecruitmentException(String msg) {
		super(msg);
	}

}
